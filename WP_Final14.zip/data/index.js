const getUserData = require("./userData");
const discussionData = require("./discussion");

module.exports = {
  userData: getUserData,
  discussion: discussionData
};